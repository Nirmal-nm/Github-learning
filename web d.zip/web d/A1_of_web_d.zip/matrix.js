function addMatrices() {
    // Loop through each cell of the 3x3 matrix
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            // Get values from Matrix A and Matrix B cells
            const aVal = parseFloat(document.getElementById(`a${i}${j}`).value) || 0;
            const bVal = parseFloat(document.getElementById(`b${i}${j}`).value) || 0;
            
            // Calculate the sum and set it in Result Matrix
            document.getElementById(`r${i}${j}`).value = aVal + bVal;
        }
    }
}
